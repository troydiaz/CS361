Nursing Management System - README
===================================

This is a simple C++ console-based program that simulates a Nursing Management System.
The program provides basic functionality for user login, viewing schedules, and checking
certification statuses.

## Files

- `main.cpp`: The source code for the Nursing Management System program.
- 'Makefile': creates executable for nursetrack.

## Compilation Instructions

   make clean && make
   ./nursetrack
